# CX Loyalty — free starter app

A responsive customer-facing stamp-card demo. No build tools or paid services required.

## Run locally
1. Unzip the folder.
2. Open `index.html` in a modern browser.
3. Create a profile and use **Add a demo stamp** to test the experience.

## Important limitations
- This starter stores profile, stamps, and history in the browser's localStorage.
- Data is only on that browser/device. Clearing browser data can erase it.
- The demo stamp button is not purchase verification. Do not use it to issue real rewards.
- For a real launch, connect a hosted database/authentication service (for example, Supabase free tier) and issue stamps only after a trusted merchant action, such as a staff/POS scan or a single-use signed QR code. A customer-only interface cannot securely validate purchases by itself.

## Free deployment — Cloudflare Pages (static)
1. Create a free GitHub account at https://github.com/ if you don't have one.
2. Create a new public repository named `cx-loyalty`.
3. Upload `index.html` to the repository root (and optionally this README).
4. Create a free Cloudflare account at https://dash.cloudflare.com/.
5. In Cloudflare, go to **Workers & Pages → Create → Pages → Connect to Git**.
6. Choose the `cx-loyalty` repository.
7. Framework preset: **None**. Build command: leave blank. Build output directory: `/` (or `.` if the UI requests it).
8. Deploy. Cloudflare will give you a `*.pages.dev` address.

## Next production step
Add Supabase authentication and database tables for customers, stamp transactions, and rewards. Put stamp issuance behind a trusted staff/POS workflow; never expose a service-role key in browser code.
